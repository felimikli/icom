#include <iostream>
#include <vector>

using namespace std;

struct Moneda {
    int denom;     // valor de la denominacion
    size_t cantidad;  // cantidad de monedas de esa denominacion
};

struct ATM {
    // Construye un cajero con el casete inicial de dinerpo
    // Las denominaciones llegan ordenadas en forma decreciente por valor.
    ATM(const vector<Moneda> &casette);       // TODO (0.20)

    // descompone el monto dado en un conjunto de monedas intentando usar 
    // las denominaciones mas grandes posibles y las cantidades disponibles
    // de cada denominacion. En caso de no tener dinero suficiente, no
    // debería entregar dinero
    vector<Moneda> descompone(int monto);            // TODO (0.80)

    vector<Moneda> casette;
};

void imprime(const vector<Moneda> &c)
{
    for(auto m : c) {
        cout << "$ " << m.denom << " #" << m.cantidad << endl;
    }
    cout << "\n";
}
int main()
{
    vector<Moneda> reserva = { {2000, 100}, {1000, 100}, {500, 100}, {200, 100}, {100, 100}, {50, 100}, {20, 100}, {10, 100}, {5, 100}, {2, 100}, {1, 100}};
    ATM mon(reserva);

    vector<Moneda> c1 = mon.descompone(300000);
    imprime(c1);
    c1 = mon.descompone(300000);
    imprime(c1);
    c1 = mon.descompone(52101);
    imprime(c1);

    return 0;
}