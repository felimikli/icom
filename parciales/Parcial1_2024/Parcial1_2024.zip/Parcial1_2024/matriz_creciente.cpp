#include <iostream>
#include <vector>

using namespace std;

// Función para reemplazar los ceros
void reemplazar_ceros(vector<vector<int>>& matriz); //TODO

// Funcion que dada una matriz (rellenada) retorna true si es creciente y false si no lo es
bool es_creciente(vector<vector<int>>& matriz); //TODO

// Función que recibe una matriz con ceros, los reemplaza y verifica si la matriz es creciente. Si lo es, devuelve la suma de sus elementos. En caso contrario, devuelve -1
int solucion(vector<vector<int>>& matriz); //TODO

// Ayuda: Funcion que imprime la matriz.
void print_matriz(vector<vector<int>>& matriz){
    for(auto vec: matriz){
        for(auto elem: vec){
            cout << elem << " ";
        }
        cout << endl;
    }
}

int main() {
    // Ejemplo de entrada
    vector<vector<int>> a = {
        {1, 2, 3},
        {3, 0, 4},
        {4, 5, 6},
    };

    vector<vector<int>> b = {
        {1, 3, 5, 6, 7},
        {3, 0, 7, 0, 9},
        {5, 0, 0, 0, 10},
        {8, 9, 10, 11, 12}
    };

    if (solucion(a) == -1 && solucion(b) == 144)
        cout << "Muy bien!" << endl;

    return 0;
}