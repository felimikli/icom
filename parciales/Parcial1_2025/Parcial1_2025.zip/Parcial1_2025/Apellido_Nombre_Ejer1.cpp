#include <vector>
#include <fstream>
#include <string>
#include <iostream>
#include <cstdint>

using namespace std;

using Pixel = uint8_t; 
using Image = vector<vector<Pixel>>;

// lee y retorna la imagen que se encuentra almacenada en el archivo fileName.
// dentro del archivo, la imagen se encuentra organizada como
// ancho, alto
// pixel0, pixel1, pixel2, ...
Image readImage(const string &fileName) 
{
    // TODO
}

// Funci0n que debe retornar un vector de SIZE/2 pixeles,(donde SIZE el el ancho/alto
// de la imagen) que corresponden a la secuencia de valores obtenidos radialmente desde el
// centro de la imagen en la direccion especificada por el angulo azimuth expresado en grados
vector<Pixel> getRadial(const Image &img, float azimuth)
{
    // TODO
}

void printRadial(const vector<Pixel> &line) 
{
    for(auto a: line)
        cout << hex << int(a) << ' ';
    cout << '\n';
}


int main()
{
    Image img = readImage("image.dat");

    for(auto az = 0.0; az < 360.0; ++az){
        vector<Pixel> radial = getRadial(img, az);
        printRadial(radial);
    }
    return 0;
}
